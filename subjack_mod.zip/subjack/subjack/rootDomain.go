package subjack

import (
	"github.com/joeguo/tldextract"
)

func getRootDomain(subdomain string) (rootDomain string) {
	cache := "/tmp/tld.cache"
	extract, _ := tldextract.New(cache,false)
	result:=extract.Extract(subdomain)
	rootDomain=result.Root+"."+result.Tld
	return rootDomain
}
