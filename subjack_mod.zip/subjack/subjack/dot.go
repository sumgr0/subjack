package subjack

import (
	"strings"
)

func dotDomain(domain string) string {
	return domain + "."
}

func removeDot(domain string) string  {
	domain=strings.TrimSuffix(domain,".")
	return domain
}

func joinHost(server string) string {
	return server + ":53"
}
